document.getElementById('current-year').textContent = new Date().getFullYear();
document.getElementById('backToTop').onclick = () => window.scrollTo({ top: 0, behavior: 'smooth' });
document.getElementById('themeToggle').onclick = () => {
    document.body.classList.toggle('dark-mode');
};